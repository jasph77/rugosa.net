<?php
define('APP_NAME','index');
define('APP_DEBUG',true);
define('APP_PATH','../Index/');
define('THINK_PATH','../ThinkPHP/');
define('URL_CASE_INSENSITIVE','true');
require_once THINK_PATH.'ThinkPHP.php';
