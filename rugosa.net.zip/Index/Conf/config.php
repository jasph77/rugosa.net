<?php
return array(
	//'配置项'=>'配置值'
	'URL_CASE_INSENSITIVE'   =>true,
	'URL_HTML_SUFFIX'        =>'.shtml',
	'url_model'              => '2', //URL模式
);
?>