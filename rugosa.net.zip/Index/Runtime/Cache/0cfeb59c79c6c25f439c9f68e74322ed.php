<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>新昌</title>
	<meta name="keywords" content="新昌农夫苗圃,苗木,花木,园林绿化,苗木价格,苗木求购,苗木企业,花木行情,青青花木网"></meta>
	<meta name="description" content=" 新昌位于位于江苏省句容市茅山镇永兴村，是华东最大的红榉树种植基地（3000亩红榉...13921555209"></meta>
	<link rel="stylesheet" href="__PUBLIC__/css/member.css"></link>
	<link rel="stylesheet" href="__PUBLIC__/css/index.css"></link>
	<script language="JavaScript" src="__PUBLIC__/js/v7.js"></script>
	<script src="http://libs.baidu.com/jquery/1.9.0/jquery.js"></script>
<style>
	[touch-action="none"]{ -ms-touch-action: none; touch-action: none; }[touch-action="pan-x"]{ -ms-touch-action: pan-x; touch-action: pan-x; }[touch-action="pan-y"]{ -ms-touch-action: pan-y; touch-action: pan-y; }[touch-action="scroll"],[touch-action="pan-x pan-y"],[touch-action="pan-y pan-x"]{ -ms-touch-action: pan-x pan-y; touch-action: pan-x pan-y; }</style>
</head>

<body>

<!-- 头部 -->
<div id="header">
	<div class="banner">
		<div class="companyname">
			<img src="__PUBLIC__/image/space1x60.gif" border="0" align="absmiddle">
			<img src="__PUBLIC__/image/logo.gif" border="0" alt="句容市茅山镇农夫苗圃" align="absmiddle">
		</div>
	</div>
	<div class="nav">
		<div class="main_menu">
			<ul>
				<li class="active">
					<a class="mnlink" href="#" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('ImageIndex','','__PUBLIC__/image/mm-index-b.jpg',1)">
						<img id="ImageIndex" name="ImageIndex" src="__PUBLIC__/image/mm-index.jpg" width="91" height="36" border="0">
					</a>
				</li>
				<li class="normal">
					<a class="mnlink" href="about.shtml" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('ImageAbout','','__PUBLIC__/image/mm-about-b.jpg',1)">
						<img id="ImageAbout" name="ImageAbout" src="__PUBLIC__/image/mm-about.jpg" width="91" height="36" border="0">
					</a>
				</li>
				<li class="normal">
					<a class="mnlink" href="product.shtml" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('ImageProduct','','__PUBLIC__/image/mm-product-b.jpg',1)">
						<img id="ImageProduct" name="ImageProduct" src="__PUBLIC__/image/mm-product.jpg" width="91" height="36" border="0">
					</a>
				</li>
				<li class="normal">
					<a class="mnlink" href="price.shtml" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('ImagePrice','','__PUBLIC__/image/mm-price-b.jpg',1)">
						<img id="ImagePrice" name="ImagePrice" src="__PUBLIC__/image/mm-price.jpg" width="91" height="36" border="0">
					</a>
				</li>
				<li class="normal">
					<a class="mnlink" href="verify.shtml" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('ImageVerify','','__PUBLIC__/image/mm-verify-b.jpg',1)">
						<img id="ImageVerify" name="ImageVerify" src="__PUBLIC__/image/mm-verify.jpg" width="91" height="36" border="0">
					</a>
				</li>
				<li class="normal">
					<a class="mnlink" href="feedback.shtml" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('ImageFeedback','','__PUBLIC__/image/mm-feedback-b.jpg',1)">
						<img id="ImageFeedback" name="ImageFeedback" src="__PUBLIC__/image/mm-feedback.jpg" width="91" height="36" border="0">
					</a>
				</li>
				<li class="normal">
					<a class="mnlink" href="linkmode.shtml" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('ImageLinkmode','','__PUBLIC__/image/mm-linkmode-b.jpg',1)">
						<img id="ImageLinkmode" name="ImageLinkmode" src="__PUBLIC__/image/mm-linkmode.jpg" width="91" height="36" border="0">
					</a>
				</li>
			</ul>
		</div>
	</div>
<div class="clear">
</div>
<!--[if lt IE 7]>
	<script language="javascript" type="text/javascript" src="__PUBLIC__/js/ie6png.js"></script>
<![endif]--> 
<div id="mid">
<script type="text/javascript">
var widths = 960;
var heights = 150;
var counts=4;
var pimg = new Array();
var purl = new Array();
var palt = new Array();
pimg[1] = 'http://www.312green.com/img/site/systemp/3/130455461531.jpg';
purl[1] = '';
palt[1] = '';
pimg[2] = 'http://www.312green.com/img/site/systemp/3/130455462114.jpg';
purl[2] = '';
palt[2] = '';
pimg[3] = 'http://www.312green.com/img/site/systemp/3/130455462657.jpg';
purl[3] = '';
palt[3] = '';
pimg[4] = 'http://www.312green.com/img/site/systemp/3/130455463201.jpg';
purl[4] = '';
palt[4] = '';
</script>
<script type="text/javascript">
	var nn = 1;
	var key = 0;
	function change_img() {
		if (key==0){
			key=1;
		} else if (document.all){
			document.getElementById("pic").filters[0].Apply();
			document.getElementById("pic").filters[0].Play(duration=2);
		}
		eval('document.getElementById("pic").src=pimg['+nn+']');
		eval('document.getElementById("url").href=purl['+nn+']');
		eval('document.getElementById("pic").alt=palt['+nn+']');
		if (counts > 1) {
		for (var i=1;i <=counts;i++){document.getElementById("xxjdjj"+i).className='axx';}
		document.getElementById("xxjdjj"+nn).className='bxx';
		}
		nn++;
		if (nn > counts){ nn = 1;}
		tt = setTimeout('change_img()',4000);
	}
	function changeimg(n){
		nn = n;
		window.clearInterval(tt);
		change_img();
	}
	document.write(' <style>');
	document.write('.axx,.bxx{padding:1px 3px 1px 6px;border:#cccccc 1px solid;margin:2px;}');
	document.write('a.axx:link,a.axx:visited{text-decoration:none;color:#fff;line-height:12px;font:9px sans-serif;background-color:#666;}');
	document.write('a.axx:active,a.axx:hover{text-decoration:none;color:#fff;line-height:12px;font:9px sans-serif;background-color:#999;}');
	document.write('a.bxx:link,a.bxx:visited{text-decoration:none;color:#fff;line-height:12px;font:9px sans-serif;background-color:#D34600;}');
	document.write('a.bxx:active,a.bxx:hover{text-decoration:none;color:#fff;line-height:12px;font:9px sans-serif;background-color:#D34600;}');
	document.write(' </style>');
	document.write(' <div style="width:'+widths+'px;height:'+heights+'px;overflow:hidden;text-overflow:clip;">');
	document.write(' <div> <a id="url"> <img id="pic" style="border:0px;filter:progid:dximagetransform.microsoft.wipe(gradientsize=1.0,wipestyle=4, motion=forward)" width='+widths+' height='+heights+' /> </a> </div>');
	if (counts > 1) {
	document.write(' <div style="filter:alpha(style=1,opacity=10,finishOpacity=80);text-align:right;top:-20px;right:4px;position:relative;padding:0px;margin:0px;border:0px;">');
	for(var i=1;i <counts+1;i++){document.write(' <a href="javascript:changeimg('+i+');" id="xxjdjj'+i+'" class="axx" target="_self">'+i+' </a>');}
	}
	document.write(' </div> </div>');
	change_img();
</script> 
</div>
</div>
<!--begin 正文 -->

<!-- 留言 -->
<div id="container">
	<div class="container_in">
	<!-- #BeginEditable "upcontainer" -->
	<!-- #EndEditable -->
	<div id="maincontent">
		<div id="path">当前位置：首页 &gt; 在线留言</div>	
	<!-- #BeginEditable "maincontent" -->
	<div class="ibox">
		 		<div class="title_b">
		 <h3>在线留言</h3>		</div>
		<div class="border_b">
	  	  <div id="pubcomment">
          <form name="feedback" action="http://www.312green.com/office/mailpub.php" method="post" target="savecomment">
          <table width="500" border="0" cellpadding="0" cellspacing="1">
              <tbody><tr>
                <td width="3%" class="zt2">&nbsp;</td>
                <td width="16%" height="24" class="zt2"><span class="zt2 STYLE1">姓&nbsp;&nbsp;名：</span></td>
                <td width="81%"><input size="20" name="name">
                <input type="hidden" name="uid" value="187052">
                </td>
              </tr>
              <tr>
                <td class="zt2">&nbsp;</td>
                <td height="24" class="zt2"><span class="zt2 STYLE1">公&nbsp;&nbsp;司：</span></td>
                <td><input size="50" name="company"></td>
              </tr>
              <tr>
                <td class="zt2">&nbsp;</td>
                <td height="24" class="zt2"><span class="zt2 STYLE1">电&nbsp;&nbsp;话：</span></td>
                <td><input size="50" name="telephone"></td>
              </tr>
              <tr>
                <td class="zt2">&nbsp;</td>
                <td height="24" class="zt2"><span class="zt2 STYLE1">E-mail：</span></td>
                <td><input size="50" name="email"></td>
              </tr>
              <tr>
                <td class="zt2">&nbsp;</td>
                <td height="24" nowrap="nowrap" class="zt2"><span class="zt2 STYLE1">详细内容：</span></td>
              <td><textarea name="content" rows="8" cols="48"></textarea>              </td></tr>
              <tr>
                <td class="zt2">&nbsp;</td>
                <td height="24" class="zt2">&nbsp;</td>
                <td>              
              </td></tr>
              <tr>
                <td class="zt2">&nbsp;</td>
                <td height="24" class="zt2">&nbsp;</td>
              <td><input type="submit" value=" 发送 " name="feedback" onclick="return chkdata(this.form)">              </td></tr>
            </tbody></table>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          </form>
		</div>
		<div id="pubnote" style="display:none">
			感谢您的留言，我们会及时与您联系的。
		</div>
	</div>
	</div>

<iframe id="savecomment" name="savecomment" width="0" height="0"></iframe>

<script language="JavaScript">
	function chkdata(myform){
		if (myform.name.value == ""){alert("你忘了写上您的大名！");return false;}
		if (myform.company.value == ""){alert("请写上您所在公司名称！");return false;}
		if (myform.telephone.value == ""){alert("请写上您的联系电话！");return false;}
		if (myform.content.value == ""){alert("反馈内容还没写呢！");return false;}
		document.getElementById("pubcomment").style.display = "none";
		document.getElementById("pubnote").style.display = "";
		return true;
	}
</script>

      <!-- #EndEditable -->
	</div>
	<div id="sidebar" style="height: 398px;">
			<!-- #BeginEditable "sidebar" -->

	<div class="ibox"><div class="title_a" style="background: url(http://www.312green.com/img/site/systemp/3/130558882563.jpg)  no-repeat left top;"></div><div class="border_a"><ul class="ul_a">
<li class="normal"><a class="mnlink" href="/price-u187052-c1005-p1.html"><span>乔灌木</span></a></li>
</ul><div class="clear"></div></div></div><div class="ibox"><div class="title_a" style="background: url(http://www.312green.com/img/site/systemp/3/130559379988.jpg)  no-repeat left top;"></div><div class="border_a"><ul class="ul_c"><table border="0" cellspacing="0" cellpadding="0"><tbody><tr valign="top"><td nowrap="nowrap">姓名：</td><td>沈德成</td></tr><tr valign="top"><td nowrap="nowrap">电话：</td><td>13921555209</td></tr><tr valign="top"><td nowrap="nowrap">QQ：</td><td><script language="javascript" type="text/javascript">QQlink(1195589417,4);</script><a href="http://wpa.qq.com/msgrd?V=1&amp;Uin=1195589417&amp;Site=青青花木网&amp;Menu=yes" target="blank"><img src="http://wpa.qq.com/pa?p=2:1195589417:4" border="0" align="absmiddle" alt="QQ号：1195589417 点击即时交流" onload="javascript:if(this.width&gt;30) this.src=&quot;http://img.312green.com/img/qqhide.gif&quot;;"></a></td></tr><tr valign="top"><td nowrap="nowrap">地址：</td><td>江苏句容永兴村</td></tr></tbody></table></ul><div class="clear"></div></div></div>
	
	<!-- #EndEditable -->
	</div>
	
	<div class="clear"></div>
	<!-- #BeginEditable "downcontainer" -->
	<!-- #EndEditable -->
	</div>
</div>
<script type="text/javascript">
$(function(){
	//首页按钮高亮
	MM_swapImage('ImageFeedBack','','__PUBLIC__/image/mm-feedback-b.jpg',1)	
	$("#ImageFeedBack").parent().removeAttr("onmouseout");
	
});	
	
</script>

<!--正文 end -->

<!--begin 页脚 -->
<div id="footer">
	<div class="footer_in">
		地址：绍兴新昌县 &nbsp;&nbsp;电话：13500000000&nbsp;<script language="javascript" type="text/javascript">QQlink(1195589417,4);</script><a href="http://wpa.qq.com/msgrd?V=1&Uin=1195589417&Site=%C7%E0%C7%E0%BB%A8%C4%BE%CD%F8&Menu=yes" target="blank"><img src="./红榉树,榉树小苗,朴树小苗,池杉,水杉,栾树,乌桕_files/pa" border="0" align="absmiddle" alt="QQ号：1195589417 点击即时交流" onload="javascript:if(this.width&gt;30) this.src=&quot;http://img.312green.com/img/qqhide.gif&quot;;"></a><br>&#169;天黑版权所有&nbsp;&nbsp;技术支持：<a href="" target="_blank">杭州雪球软件有限公司</a>&nbsp;&nbsp;<br> 
		<script type="text/javascript">
var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3F39e79d0c896ac2fc7735334d85508494' type='text/javascript'%3E%3C/script%3E"));
		</script>
		<script src="http://hm.baidu.com/h.js?39e79d0c896ac2fc7735334d85508494" type="text/javascript">
		</script>
	<div style="display:none">
		<script language="javascript" type="text/javascript" src="./红榉树,榉树小苗,朴树小苗,池杉,水杉,栾树,乌桕_files/1459396.js"></script>
		<a href="" target="_blank" title="我要啦免费统计 VIP 用户">贵宾统计</a>
	</div>
	</div>
</div>
<!-- 页脚 end -->
</body>
</html>